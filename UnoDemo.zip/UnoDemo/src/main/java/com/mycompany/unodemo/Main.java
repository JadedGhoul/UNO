package com.mycompany.unodemo;


public class Main {
    public static void main(String[]args)throws Exception
    {
       new Menu().setVisible(true); 
    }
}
